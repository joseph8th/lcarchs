Downloaded from LCARS Standards Development Board Website
http://www.starbasemccoy.com/lcars/

===============================
Feel free to redistribute this file. 
For more LCARS downloads and information, visit:
http://www.starbasemccoy.com/lcars/