#!/usr/bin/python
import os,random,gconf,time

BG_PATH = '/usr/share/themes/LCARS-Desktop/backgrounds/'
gconf_path= "/desktop/gnome/background/picture_filename"

time.sleep(10)

if(__name__=='__main__'):
    while True:
        pipe = os.popen('ls '+BG_PATH)
        bgnames = pipe.readlines()
        pipe.close()
        
    
        rnd = random.randint(0,len(bgnames)-1)
        newBG = BG_PATH+(bgnames[rnd].strip())
        print newBG
        gconf.client_get_default().set_string(gconf_path,newBG)
        
        #cmdstr = 'fbsetbg -a '+BG_PATH+(bgnames[rnd].strip())
        #print cmdstr
        #os.system(cmdstr)


        
        # sleep for 15 minutes before picking a new background
        time.sleep(900)
